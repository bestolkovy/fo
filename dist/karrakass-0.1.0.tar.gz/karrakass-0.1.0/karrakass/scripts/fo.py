from colorama import Fore


def main():
    print(Fore.RED + 'fuck off, mazafaka и хуй ипаный')


if __name__ == '__main__':
    main()
